import Layout from "./components/Layout";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./components/Home/Home";
import PageNotFound from "./components/PageNotFound";
import ParentRegistration from "./components/authPage/ParentRegistration";
import TutorSearchPage from "./components/TutorPage/TutorSearchPage";
import Login from "./components/authPage/Login";
import TutorDetail from "./components/TutorPage/TutorDetail";
import AboutPage from "./components/AboutPage";
import TutorRegistration from "./components/authPage/TutorRegistration";
import {
  AppointmentBasedOnRole,
  DashboardBasedOnRole,
  ProfileBasedOnRole,
  ProtectedRoute,
} from "./components/services/ProtectRoute";
import { Toaster } from "react-hot-toast";
import EditTutorProfile from "./components/TutorPage/TutorDashboardComponents/EditTutorProfile";
import Message from "./components/Message";

function App() {
  return (
    <>
      <BrowserRouter>
        <Layout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<ParentRegistration />} />
            <Route path="/tutor/signup" element={<TutorRegistration />} />
            <Route path="/search/tutors" element={<TutorSearchPage />} />
            <Route
              path="/dashboard"
              element={
                <ProtectedRoute>
                  <DashboardBasedOnRole />
                </ProtectedRoute>
              }
            >
              {/* Define child routes under the parent route */}
              <Route
                path="profile"
                element={
                  <ProtectedRoute>
                    <ProfileBasedOnRole />
                  </ProtectedRoute>
                }
              />
              <Route
                path="appointments"
                element={
                  <ProtectedRoute>
                    <AppointmentBasedOnRole />
                  </ProtectedRoute>
                }
              />
              <Route path="messages" element={<Message />} />
            </Route>

            <Route
              path="/tutor/detail-page/:tutorId"
              element={<TutorDetail />}
            />
            <Route path="/tutor/profile/edit" element={<EditTutorProfile />} />

            <Route path="/about" element={<AboutPage />} />

            <Route path="*" element={<PageNotFound />} />
          </Routes>
        </Layout>
      </BrowserRouter>
      <Toaster />
    </>
  );
}

export default App;
