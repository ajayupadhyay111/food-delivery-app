import React, { useState } from "react";
import DatePicker from "react-datepicker";
import Select from "react-select";
import "react-datepicker/dist/react-datepicker.css";
import { axiosInstance } from "../utils/axios";
import toast from "react-hot-toast";
import { useNavigate } from "react-router-dom";
import { X } from "lucide-react";

const generateTimeOptions = () => {
  let options = [];
  for (let hour = 0; hour < 24; hour++) {
    for (let minute = 0; minute < 60; minute += 15) {
      let formattedHour = hour % 12 === 0 ? 12 : hour % 12;
      let amPm = hour < 12 ? "AM" : "PM";
      let formattedTime = `${formattedHour}:${minute
        .toString()
        .padStart(2, "0")} ${amPm}`;
      options.push({ value: formattedTime, label: formattedTime });
    }
  }
  return options;
};

const DateTimePicker = ({ id, setShowModal }) => {
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const navigate = useNavigate();

  const handleAppointment = async () => {
    let dd = new Date(selectedDate);
    if (dd < new Date()) {
      toast.error("Please select a valid date");
      return;
    }
    let date =
      `${dd.getDate() < 10 ? `0${dd.getDate()}` : `${dd.getDate()}`}/${
        dd.getMonth() + 1 < 10
          ? `0${dd.getMonth() + 1}`
          : `${dd.getMonth() + 1}`
      }/${dd.getFullYear()}` +
      " " +
      selectedTime;
    console.log(date);
    try {
      const response = await axiosInstance.post(`/appointment/create/${id}`, {
        appointmentDate: date,
      });
      console.log(response);
      if (response.status === 201) {
        navigate(`/tutor/detail-page/${id}`);
        toast.success(response.data.message);
      }
    } catch (error) {
      console.log(error.message);
    }
  };

  return (
    <div className="z-20 fixed inset-0 flex items-center justify-center bg-gray-800  bg-opacity-50">
      <div className=" bg-gray-900 p-6 rounded-lg shadow-lg w-96 animate-fadeIn">
        {/* Close Button */}
        <div className="flex justify-end">
          <p className="w-fit" onClick={() => setShowModal((prev) => !prev)}>
            <X />
          </p>
        </div>
        <div className="flex flex-col items-center justify-center p-5  rounded-lg max-w-md mx-auto">
          <h2 className="text-xl font-semibold text-gray-200 mb-4">
            Select Date & Time
          </h2>

          {/* Date Picker */}
          <DatePicker
            selected={selectedDate}
            onChange={(date) => setSelectedDate(date)}
            dateFormat="dd/MM/yyyy"
            placeholderText="dd/mm/yyyy"
            className="px-4 py-2 w-full rounded-md shadow-md focus:outline-none mb-4"
            calendarClassName="bg-white rounded-md shadow-lg p-2"
          />

          {/* Time Picker */}
          <div className="flex flex-col items-center justify-center p-5 bg-gray-800 rounded-lg max-w-md mx-auto">
            <h2 className="text-xl font-semibold text-gray-200 mb-4">
              Select a Time
            </h2>

            <Select
              options={generateTimeOptions()}
              onChange={(option) => setSelectedTime(option.value)}
              placeholder="Choose Time"
              className="w- text-gray-900"
            />

            {selectedTime && (
              <p className="mt-4 text-gray-300">
                Selected Time: <span className="font-bold">{selectedTime}</span>
              </p>
            )}
          </div>

          <button onClick={handleAppointment} className="btn btn-primary mt-5">
            Book Appointment
          </button>
        </div>
      </div>
    </div>
  );
};

export default DateTimePicker;
