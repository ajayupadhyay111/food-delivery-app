import { useEffect, useState } from "react";
import { io } from "socket.io-client";

const socket = io("http://localhost:3000"); // Backend URL

const Message = () => {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");

  const currentUser = {
    _id: "1",
    name: "John Doe",
    role: "parent", // Assuming 'parent' is a role in the system
  };

  const receiver = {
    _id: "2",
    name: "Jane Doe",
    role: "tutor", // Assuming 'tutor' is a role in the system
  };

  useEffect(() => {
    // ✅ Join Message
    socket.emit("join", {
      userId: currentUser._id,
      userType: currentUser.role,
    });

    // ✅ Receive message
    socket.on("receiveMessage", (message) => {
      console.log("📨 New message:", message);
      setMessages((prev) => [...prev, message]);
    });

    return () => {
      socket.off("receiveMessage");
    };
  }, []);

  // ✅ Send message
  const sendMessage = () => {
    if (newMessage.trim() === "") return;

    const messageData = {
      userType: currentUser.role,
      senderId: currentUser._id,
      receiverId: receiver._id,
      content: newMessage,
    };

    socket.emit("sendMessage", messageData);
    setMessages((prev) => [...prev, messageData]);
    setNewMessage("");
  };

  return (
    <div className="Message-container">
      <h2>Message with {receiver.name}</h2>
      <div className="messages">
        {messages.map((msg, index) => (
          <p
            key={index}
            className={msg.senderId === currentUser._id ? "sent" : "received"}
          >
            {msg.content}
          </p>
        ))}
      </div>
      <div className="input-box">
        <input
          type="text"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder="Type a message..."
        />
        <button onClick={sendMessage}>Send</button>
      </div>
    </div>
  );
};

export default Message;
