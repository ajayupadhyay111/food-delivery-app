import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";

import { setUser } from "../../redux/features/userSlice";
import toast from "react-hot-toast";
import { axiosInstance } from "../../utils/axios";

const Login = () => {
  const [isLoading, setIsLoading] = useState(false);
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [credentials, setCredentials] = useState({
    email: "",
    password: "",
    role: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCredentials((prevState) => ({ ...prevState, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setIsLoading(true);
      const response = await axiosInstance.post("/auth/login", credentials);
      if (response?.status === 200) {
        dispatch(setUser(response?.data.data));
        toast.success(response?.data.message);
        navigate("/");
      }
    } catch (err) {
      console.error("Error:", err);
      toast.error(err?.response?.message || "Login Failed");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="mt-20 mb-10 w-full h-[85vh] flex flex-col items-center justify-center">
      <div className="max-w-lg w-lg mx-auto p-6 bg-gray-800 text-white rounded-lg shadow-lg">
        <h2 className="text-2xl font-bold mb-4 text-center">Login</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <input
              type="email"
              name="email"
              value={credentials.email}
              onChange={handleChange}
              placeholder="Email"
              className="w-full p-3 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400"
              required
            />
          </div>
          <div>
            <input
              type="password"
              name="password"
              value={credentials.password}
              onChange={handleChange}
              placeholder="Password"
              className="w-full p-3 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400"
              required
            />
          </div>
          <div>
            <select
              name="role"
              value={credentials.role}
              onChange={handleChange}
              className="w-full p-3 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400"
              required
            >
              <option value="" disabled>
                Select Role
              </option>
              <option value="tutor">Tutor</option>
              <option value="parent">Parent</option>
            </select>
          </div>
          <div>
            <button
              disabled={isLoading}
              type="submit"
              className={`w-full p-3 bg-blue-500 hover:bg-blue-600 rounded-lg font-bold ${
                isLoading ? "cursor-not-allowed" : "cursor-pointer"
              }`}
            >
              {isLoading ? "Logging..." : "Login"}
            </button>
          </div>
        </form>
        <p className="mt-3">
          Don't have an account?{" "}
          <Link to="/signup" className=" text-blue-500 hover:text-blue-600">
            Sign Up
          </Link>
        </p>
      </div>
    </div>
  );
};

export default Login;
