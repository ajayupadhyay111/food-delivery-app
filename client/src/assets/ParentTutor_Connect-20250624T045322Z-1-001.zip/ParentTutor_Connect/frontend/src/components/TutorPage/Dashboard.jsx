import React, { useEffect } from "react";
import {
  CalendarDays,
  LayoutDashboard,
  LogOut,
  MessageCircleMore,
  User2,
} from "lucide-react";
import { Link, NavLink, Outlet } from "react-router-dom";
import { useDispatch } from "react-redux";
import { logout } from "../../redux/features/userSlice";

const TutorDashboard = () => {
  const dispatch = useDispatch();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  const handleLogout = () => {
    dispatch(logout());
  };
  return (
    <div className="flex mb-5 mt-16 md:mt-24">
      {/* Sidebar */}
      <aside className=" w-16 lg:w-64 md:w-68 p-4">
        <h2 className="text-xl font-bold mb-6">
          <span className="hidden md:block">Parent Dashboard </span>
        </h2>
        <ul className="">
          <NavLink
            to={"/dashboard/profile"}
            className={({ isActive }) =>
              isActive
                ? " text-primary text-xl bg-gray-600 w-full transition-all duration-200 rounded-lg"
                : "text-base-content text-xl hover:bg-gray-700  transition-all duration-200 rounded-lg"
            }
          >
            <li className="md:p-2 py-4 text-xl md:hover:bg-gray-600 rounded">
              <span className="hidden md:block">Profile</span>
              <User2 className="md:hidden" />
            </li>
          </NavLink>
          <NavLink
            to={"/dashboard/appointments"}
            className={({ isActive }) =>
              isActive
                ? " text-primary text-xl bg-gray-600 w-full transition-all duration-200 rounded-lg"
                : "text-base-content text-xl hover:bg-gray-700  transition-all duration-200 rounded-lg"
            }
          >
            <li className="md:p-2 py-4 text-xl md:hover:bg-gray-600 rounded">
              <span className="hidden md:block">Appointments</span>
              <CalendarDays className="md:hidden" />
            </li>
          </NavLink>
          <NavLink
            to={"/dashboard/messages"}
            className={({ isActive }) =>
              isActive
                ? " text-primary text-xl bg-gray-600 w-full transition-all duration-200 rounded-lg"
                : "text-base-content text-xl hover:bg-gray-700  transition-all duration-200 rounded-lg"
            }
          >
            <li className="md:p-2 py-4 text-xl md:hover:bg-gray-600 rounded">
              <span className="hidden md:block">Message</span>
              <MessageCircleMore className="md:hidden" />
            </li>
          </NavLink>
          <li className="md:p-2 py-4 text-xl   md:hover:bg-gray-600 rounded">
            <label htmlFor="my_modal_6">
              <span className="hidden md:block">Logout</span>
              <LogOut className="md:hidden" />
            </label>
          </li>

          {/* //model */}
          {/* Put this part before </body> tag */}
          <input type="checkbox" id="my_modal_6" className="modal-toggle" />
          <div className="modal" role="dialog">
            <div className="modal-box">
              <h3 className="text-lg font-bold">Hello!</h3>
              <p className="mt-3 text-lg">Are you sure ?</p>
              <div className="modal-action" onClick={handleLogout}>
                <label htmlFor="my_modal_6" className="btn btn-error">
                  Logout
                </label>
              </div>
            </div>
          </div>
        </ul>
      </aside>

      {/* Main Content */}
      <main className="flex-1 ">
        <Outlet />
      </main>
    </div>
  );
};

export default TutorDashboard;
