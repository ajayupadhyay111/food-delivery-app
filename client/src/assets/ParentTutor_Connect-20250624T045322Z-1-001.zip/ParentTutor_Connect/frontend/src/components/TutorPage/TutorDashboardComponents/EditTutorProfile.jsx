import React, { useRef, useState } from "react";
import { axiosInstance } from "../../../utils/axios";
import { Loader2 } from "lucide-react";
import { Navigate, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

export default function EditTutorProfile({ tutor, setEditable, setTutor }) {
  // const tutor = {
  //   image: "https://randomuser.me/api/portraits/men/10.jpg",
  //   name: "John Doe",
  //   email: "johndoe@example.com",
  //   phone: "+1 234 567 890",
  //   qualification: "M.Sc in Mathematics",
  //   subjects: ["Math", "Science", "English"],
  //   address: "221B Baker Street, London, UK",
  //   experience: 5,
  //   hourlyRate: 30,
  //   availability: "Monday to Friday, 10 AM - 6 PM",
  // };
  const [formData, setFormData] = useState({ ...tutor });
  const [progress, setProgress] = useState(0);
  const [preview, setPreview] = useState(tutor.profilePicture);
  const [uploadedUrl, setUploadedUrl] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Handle subjects input (comma-separated)
  const handleSubjectsChange = (e) => {
    setFormData({
      ...formData,
      subjects: e.target.value.split(",").map((s) => s.trim()),
    });
  };

  const handleImageChange = async (e) => {
    const profilePic = e.target.files[0];

    if (!profilePic) {
      alert("Please select an image first!");
      return;
    }
    setPreview(URL.createObjectURL(profilePic)); // Show preview

    try {
      setIsLoading(true);
      const response = await axiosInstance.put(
        "/profile/upload-image",
        { profilePic },
        {
          headers: { "Content-Type": "multipart/form-data" },
          onUploadProgress: (progressEvent) => {
            const percent = Math.round(
              (progressEvent.loaded * 100) / progressEvent.total
            );
            setProgress(percent); // Update progress state
          },
        }
      );

      setUploadedUrl(response.data.url); // Backend should return uploaded image URL

      setProgress(0); // Reset progress after upload
    } catch (error) {
      console.error("Upload failed:", error);
      alert("Upload failed, please try again!");
    } finally {
      setIsLoading(false);
    }
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axiosInstance.put(
        "/profile/update/tutorProfile",
        formData
      );
      if (response.status === 200) {
        setTutor(response.data.updatedTutor);
        setEditable((prev) => !prev);
        toast.success("Profile updated successfully");
      }
    } catch (error) {
      console.log(error);
    }
  };

  const inputRef = useRef();

  return (
    <form className="max-w-2xl md:px-0 px-5 mx-auto">
      <h1 className=" font-bold text-xl text-center mt-10">
        Update Tutor Profile
      </h1>
      <div className="mt-10 flex justify-center">
        {isLoading ? (
          <div className="w-32 rounded-full h-32 flex justify-center items-center">
            <Loader2 className="" />
          </div>
        ) : (
          <img
            onClick={() => inputRef.current.click()}
            src={preview || tutor.profilePicture}
            alt="tutor photo"
            className="w-32 rounded-full h-32 object-cover"
          />
        )}
        <input
          ref={inputRef}
          type="file"
          accept="/*"
          name="profilePicture"
          onChange={handleImageChange}
          className="hidden"
        />
      </div>
      <div className="flex gap-4">
        <input
          type="text"
          name="fullName"
          value={formData.fullName}
          onChange={handleChange}
          className="mt-4 w-full flex-1 p-3 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400 text-white"
        />
        <input
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          className="mt-4 w-full flex-1 p-3 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400 text-white"
        />
      </div>
      <div className="flex gap-4">
        <input
          type="text"
          name="phoneNumber"
          value={formData.phoneNumber || ""}
          onChange={handleChange}
          placeholder="Phone Number"
          className="mt-4 w-full flex-1 p-3 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400 text-white"
        />
        <input
          type="text"
          name="address"
          onChange={handleChange}
          value={formData.address}
          placeholder="Address"
          className="mt-4 w-full flex-1 p-3 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400 text-white"
        />
      </div>
      <div>
        <input
          type="text"
          name="qualifications"
          value={formData.qualifications || ""}
          onChange={handleChange}
          placeholder="Qualification"
          className="mt-4 w-full flex-1 p-3 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400 text-white"
        />
      </div>
      <div>
        <input
          type="text"
          name="subjects"
          value={formData.subjects}
          onChange={handleSubjectsChange}
          placeholder="Subjects (comma-separated)"
          className="mt-4 w-full flex-1 p-3 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400 text-white"
        />
      </div>
      <div className="flex gap-4">
        <input
          type="text"
          name="availability"
          value={formData.availability}
          onChange={handleChange}
          placeholder="mon-tue,10am-3pm"
          className="mt-4 w-full flex-1 p-3 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400 text-white"
        />
        <input
          type="text"
          name="hourlyRate"
          value={`${formData.hourlyRate}`}
          onChange={handleChange}
          placeholder="Hourly Rate (₹)"
          className="mt-4 w-full flex-1 p-3 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400 text-white"
        />
      </div>
      <div className="flex items-center mt-5 gap-4">
        <button
          type="submit"
          className="bg-blue-500 text-white rounded-md px-4 py-2"
          onClick={handleSubmit}
        >
          Update
        </button>
        <button
          className="btn btn-error"
          onClick={() => setEditable((prev) => !prev)}
        >
          Cancel
        </button>
      </div>
    </form>
  );
}
