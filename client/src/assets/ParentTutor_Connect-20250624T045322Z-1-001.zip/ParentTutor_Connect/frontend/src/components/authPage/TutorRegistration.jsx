import { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { setUser } from "../../redux/features/userSlice";
import toast from "react-hot-toast";

const TutorRegistration = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  const fileRef = useRef();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [tutor, setTutor] = useState({
    fullName: "",
    email: "",
    password: "",
    qualifications: "",
    subjects: "",
    experience: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setTutor((prevState) => ({ ...prevState, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setIsLoading(true);
      const response = await axiosInstance.post("/auth/registerTutor", tutor);
      if (response.status === 201) {
        toast.success(response.message);
      }
      setTutor(response.tutor);
    } catch (error) {
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto mt-20 mb-10 p-6 bg-gray-800 text-white rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold mb-4 text-center">
        Tutor Registration
      </h2>
      <form
        onSubmit={handleSubmit}
        className="flex flex-col  gap-5 items-center"
      >
        <div className=" w-48 h-48 relative overflow-hidden rounded-full">
          <img
            src="https://img.freepik.com/premium-vector/default-image-icon-vector-missing-picture-page-website-design-mobile-app-no-photo-available_87543-11093.jpg"
            alt=""
            className="rounded-full w-full h-full shadow-2xl object-cover"
          />
          <input
            ref={fileRef}
            type="file"
            name="profilePicture"
            className="hidden w-full p-3 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400"
            accept="image/*"
          />
          <div
            onClick={() => fileRef.current.click()}
            className="absolute bottom-0 bg-white text-xl text-black flex items-center justify-center w-full text-center h-16  pb-3 hover:bg-gray-300 "
          >
            uploadImage
          </div>
        </div>
        <div className="w-full flex gap-5">
          <input
            type="text"
            name="fullName"
            value={tutor.fullName}
            onChange={handleChange}
            placeholder="Full Name"
            className="w-full p-3 flex-1 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400"
            required
          />

          <input
            type="email"
            name="email"
            value={tutor.email}
            onChange={handleChange}
            placeholder="Email"
            className="w-full p-3 flex-1 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400"
            required
          />
        </div>
        <div className="w-full flex gap-5">
          <input
            type="password"
            name="password"
            value={tutor.password}
            onChange={handleChange}
            placeholder="Password"
            className="w-full p-3 flex-1 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400"
            required
          />
          <input
            type="text"
            name="qualifications"
            value={tutor.qualifications}
            onChange={handleChange}
            placeholder="Qualifications (comma separted)"
            className="w-full p-3 flex-1 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400"
            required
          />
        </div>
        <div className="w-full flex gap-5">
          <input
            type="text"
            name="subjects"
            value={tutor.subjects}
            onChange={handleChange}
            placeholder="Subjects (comma separated)"
            className="w-full p-3 flex-1 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400"
            required
          />
          <input
            type="text"
            name="experience"
            value={tutor.experience}
            onChange={handleChange}
            placeholder="Experience (comma separted)"
            className="w-full p-3 flex-1 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400"
            required
          />
        </div>
        <div className="w-full ">
          <button
            type="submit"
            className="w-full p-3 bg-blue-500 hover:bg-blue-600 rounded-lg font-bold"
          >
            Register
          </button>
        </div>
      </form>
      <p className="mt-3">
        Already have an account?{" "}
        <Link to="/login" className=" text-blue-500 hover:text-blue-600 ">
          Login
        </Link>
      </p>
    </div>
  );
};

export default TutorRegistration;
