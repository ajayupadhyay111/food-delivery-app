import React, { useEffect, useState } from "react";
import { useLoaderData, useLocation, useNavigate } from "react-router-dom";
import { axiosInstance } from "../../../utils/axios";
import toast from "react-hot-toast";
import EditTutorProfile from "./EditTutorProfile";

export default function TutorProfile() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  // const tutor = {
  //   image: "https://randomuser.me/api/portraits/men/10.jpg", // Dummy Image URL
  //   name: "John Doe",
  //   email: "johndoe@example.com",
  //   phone: "+1 234 567 890",
  //   qualification: "M.Sc in Mathematics",
  //   subjects: ["Math", "Science", "English"],
  //   address: "221B Baker Street, London, UK",
  //   experience: 5, // Years of experience
  //   hourlyRate: 30, // Dollars per hour
  //   availability: "Monday to Friday, 10 AM - 6 PM",
  // };

  const [editable, setEditable] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [tutor, setTutor] = useState({});
  const [formData, setFormData] = useState({});

  // Handle form submission
  useEffect(() => {
    (async () => {
      try {
        setIsLoading(true);
        const response = await axiosInstance.get("/profile/tutorProfile");
        if (response?.status === 200) {
          setTutor(response.data.tutor);
          setFormData(response.data.tutor);
        }
      } catch (error) {
        console.log(error.message);
        toast.error(error?.response?.message);
      } finally {
        setIsLoading(false);
      }
    })();
  }, []);

  return (
    <div className=" w-full lg:max-w-2xl mx-auto p-6 bg-gray-900 text-white rounded-lg shadow-lg">
      {/* Profile Image */}
      <div className="flex flex-col items-center">
        <img
          src={tutor?.profilePicture}
          alt="Tutor"
          className="w-24 h-24 rounded-full object-cover border-4 border-blue-500"
        />
        <h2 className="mt-3 text-2xl font-bold text-blue-400">
          {tutor?.fullName}
        </h2>
      </div>

      {/* Email & Phone */}
      <p className="mt-2 text-gray-300">📧 {tutor?.email}</p>
      <p className="text-gray-300">
        📞 {tutor?.phoneNumber ? `${tutor?.phoneNumber}` : "Not provided"}
      </p>

      {/* Qualification */}
      <h3 className="mt-4 text-lg font-semibold">🎓 Qualification:</h3>
      <p className="text-gray-300">{tutor?.qualification || "Not provided"}</p>

      {/* Subjects */}
      <h3 className="mt-4 text-lg font-semibold">📚 Subjects:</h3>
      <ul className="list-disc list-inside text-gray-300">
        {tutor?.subjects?.length > 0 ? (
          tutor?.subjects.map((subject, index) => (
            <li key={index}>{subject}</li>
          ))
        ) : (
          <p className="text-gray-500">No subjects selected</p>
        )}
      </ul>

      {/* Address */}
      <h3 className="mt-4 text-lg font-semibold">📍 Address:</h3>
      <p className="text-gray-300">{tutor?.address || "No address provided"}</p>

      {/* Experience */}
      <h3 className="mt-4 text-lg font-semibold">📝 Experience:</h3>
      <p className="text-gray-300">
        {tutor?.experience ? `${tutor?.experience} years` : "Not provided"}
      </p>

      {/* Hourly Rate */}
      <h3 className="mt-4 text-lg font-semibold">💰 Hourly Rate:</h3>
      <p className="text-gray-300">
        {tutor?.hourlyRate ? `$${tutor?.hourlyRate}/hr` : "Not provided"}
      </p>

      {/* Availability */}
      <h3 className="mt-4 text-lg font-semibold">⏳ Availability:</h3>
      <p className="text-gray-300">
        {tutor?.availability?.[0] || "Not provided"}
      </p>
      <div className="flex justify-end">
        <button
          onClick={() => setEditable((prev) => !prev)}
          className="btn btn-primary"
        >
          Edit Profile
        </button>
      </div>
      {editable && (
        <div className="w-full bg-gray-900 fixed left-0 z-50 top-0 h-screen">
          <EditTutorProfile
            tutor={formData}
            setEditable={setEditable}
            setTutor={setTutor}
          />
        </div>
      )}
    </div>
  );
}
