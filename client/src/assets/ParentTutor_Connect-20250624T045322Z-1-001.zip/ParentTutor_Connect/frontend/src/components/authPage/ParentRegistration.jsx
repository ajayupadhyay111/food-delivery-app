import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { axiosInstance } from "../../utils/axios";
import { useDispatch } from "react-redux";
import { setUser } from "../../redux/features/userSlice";
import toast from "react-hot-toast";

const ParentRegistration = () => {
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  const [parent, setParent] = useState({
    fullName: "",
    email: "",
    phoneNumber: "",
    password: "",
    children: [
      {
        name: "",
        age: "",
        grade: "",
        subjectInterests: [],
      },
    ],
  });

  // Handle input changes for parent details
  const handleParentChange = (e) => {
    const { name, value } = e.target;
    setParent({ ...parent, [name]: value });
  };

  // Handle input changes for child details
  const handleChildChange = (index, e) => {
    const { name, value } = e.target;
    const updatedChildren = [...parent.children];
    updatedChildren[index][name] = value;
    setParent({ ...parent, children: updatedChildren });
  };

  // Handle subject interests
  const handleSubjectChange = (index, e) => {
    const { value } = e.target;
    const updatedChildren = [...parent.children];
    updatedChildren[index].subjectInterests = value; // Store raw string input
    setParent({ ...parent, children: updatedChildren });
  };

  // Add a new child
  const addChild = () => {
    setParent({
      ...parent,
      children: [
        ...parent.children,
        { name: "", age: "", grade: "", subjectInterests: [] },
      ],
    });
  };

  // Remove a child
  const removeChild = (index) => {
    const updatedChildren = parent.children.filter((_, i) => i !== index);
    setParent({ ...parent, children: updatedChildren });
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setIsLoading(true);
      const response = await axiosInstance.post("/auth/registerParent", parent);
      if (response.status === 201) {
        toast.success(response.message);
      }
    } catch (error) {
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section className="text-gray-300 py-12 px-6 mt-15">
      <div className="max-w-4xl mx-auto bg-gray-800 p-8 rounded-lg shadow-lg">
        <h2 className="text-3xl font-bold text-white text-center mb-6">
          Parent Registration
        </h2>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Parent Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm">Full Name</label>
              <input
                type="text"
                name="fullName"
                value={parent.fullName}
                onChange={handleParentChange}
                className="w-full p-3 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400 text-white"
                required
              />
            </div>
            <div>
              <label className="block text-sm">Email</label>
              <input
                type="email"
                name="email"
                value={parent.email}
                onChange={handleParentChange}
                className="w-full p-3 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400 text-white"
                required
              />
            </div>
            <div>
              <label className="block text-sm">Phone Number</label>
              <input
                type="tel"
                name="phoneNumber"
                value={parent.phoneNumber}
                onChange={handleParentChange}
                className="w-full p-3 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400 text-white"
                required
              />
            </div>
            <div>
              <label className="block text-sm">Password</label>
              <input
                type="password"
                name="password"
                value={parent.password}
                onChange={handleParentChange}
                className="w-full p-3 rounded-lg bg-gray-700 border border-gray-600 focus:outline-none focus:border-blue-400 text-white"
                required
              />
            </div>
          </div>

          <h3 className="text-2xl font-semibold text-white mt-6">
            Children Details
          </h3>

          {parent.children.map((child, index) => (
            <div key={index} className="bg-gray-700 p-4 rounded-lg mt-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm">Child's Name</label>
                  <input
                    type="text"
                    name="name"
                    value={child.name}
                    onChange={(e) => handleChildChange(index, e)}
                    className="w-full p-3 rounded-lg bg-gray-800 border border-gray-600 focus:outline-none focus:border-blue-400 text-white"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm">Age</label>
                  <input
                    type="number"
                    name="age"
                    value={child.age}
                    onChange={(e) => handleChildChange(index, e)}
                    className="w-full p-3 rounded-lg bg-gray-800 border border-gray-600 focus:outline-none focus:border-blue-400 text-white"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm">Grade</label>
                  <input
                    type="text"
                    name="grade"
                    value={child.grade}
                    onChange={(e) => handleChildChange(index, e)}
                    className="w-full p-3 rounded-lg bg-gray-800 border border-gray-600 focus:outline-none focus:border-blue-400 text-white"
                    required
                  />
                </div>
              </div>

              <div className="mt-3">
                <label className="block text-sm">
                  Subject Interests (comma separated)
                </label>
                <input
                  type="text"
                  name="subjectInterests"
                  value={child.subjectInterests} // Store raw string
                  onChange={(e) => handleSubjectChange(index, e)}
                  className="w-full p-3 rounded-lg bg-gray-800 border border-gray-600 focus:outline-none focus:border-blue-400 text-white"
                  required
                />
              </div>

              <div className="mt-4 text-right">
                {index > 0 && (
                  <button
                    type="button"
                    onClick={() => removeChild(index)}
                    className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg"
                  >
                    Remove Child
                  </button>
                )}
              </div>
            </div>
          ))}

          <div className="text-center mt-4">
            <button
              type="button"
              onClick={addChild}
              className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded-lg"
            >
              Add Another Child
            </button>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-green-500 hover:bg-green-600 text-white py-3 rounded-lg text-lg font-semibold mt-6"
          >
            {isLoading ? "..." : "Register"}
          </button>
        </form>
        <p className="mt-2">
          Already have an account?{" "}
          <Link to="/login" className="  text-blue-500 hover:text-blue-600">
            Login
          </Link>
        </p>
        <p className="mt-2">
          Register as a tutor?{" "}
          <Link
            to="/tutor/signup"
            className="  text-blue-500 hover:text-blue-600"
          >
            register
          </Link>
        </p>
      </div>
    </section>
  );
};

export default ParentRegistration;
