import React from "react";
import { useSelector } from "react-redux";
import { Navigate, useNavigate } from "react-router-dom";
import ParentDashboard from "../parentPages/Dashboard";
import TutorDashboard from "../TutorPage/Dashboard";
import ParentProfile from "../parentPages/ParentProfile";
import TutorProfile from "../TutorPage/TutorDashboardComponents/TutorProfile";
import Appointments from "../parentPages/Appointments";
import TutorAppointments from "../TutorPage/TutorDashboardComponents/TutorAppointments";

export const ProtectedRoute = ({ children }) => {
  const { isAuthenticated } = useSelector((state) => state.user);
  if (!isAuthenticated) {
    return <Navigate to={"/login"} />;
  }
  return children;
};

export const DashboardBasedOnRole = () => {
  const navigate = useNavigate();
  const { user } = useSelector((state) => state.user);
  if (user?.role === "parent") {
    return <ParentDashboard />;
  } else if (user?.role === "tutor") {
    return <TutorDashboard />;
  } else {
    navigate("/login");
  }
};

export const ProfileBasedOnRole = () => {
  const { user } = useSelector((state) => state.user);
  if (user.role === "parent") {
    return <ParentProfile />;
  } else if (user.role === "tutor") {
    return <TutorProfile />;
  }
};
export const AppointmentBasedOnRole = () => {
  const { user } = useSelector((state) => state.user);
  if (user.role === "parent") {
    return <Appointments />;
  } else if (user.role === "tutor") {
    return <TutorAppointments />;
  }
};
