import React, { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { axiosInstance } from "../../utils/axios";

const Appointments = () => {
  const [modalOpen, setModalOpen] = useState(false);

  const [appointments, setAppointments] = useState([]);

  useEffect(() => {
    (async () => {
      try {
        const response = await axiosInstance.get(
          "/appointment/appointmentsbyParent"
        );
        setAppointments(response.data.appointments);
        console.log(response);
      } catch (error) {
        console.log(error.message);
        toast.error(error.response.message);
      }
    })();
  }, []);

  const deleteAppointment = async (id) => {
    try {
      const response = await axiosInstance.delete(`/appointment/${id}`);
      if (response.status === 200) {
        toast.success(response.data.message);
        setAppointments(
          appointments.filter((appointment) => appointment._id !== id)
        );
      }
    } catch (error) {
      console.log(error.message);
      toast.error(error?.response?.message || error.message);
    }
  };

  return (
    <div className=" min-h-screen w-full bg-gray-800 md:p-6 p-3">
      <div className="  rounded-lg lg:p-6 w-full">
        <div className="w-full">
          <h3 className="text-xl font-semibold mb-4">Previous Appointments</h3>
          {appointments?.length > 0 ? (
            <div className="space-y-3 flex gap-3 flex-wrap w-full">
              {appointments?.map((appointment, index) => (
                <div
                  className="w-full border-2 lg:flex px-2 pt-3 lg:p-4 lg:px-0 lg:items-start lg:justify-between rounded-md "
                  key={appointment._id}
                >
                  <div className="flex items-center">
                    <div className="lg:pl-5 flex md:flex-col gap-4 justify-between w-full">
                      <div>
                        <h1 className="text-gray-300 font-bold text-lg md:text-xl">
                          {appointment?.tutorId.fullName}
                        </h1>
                        <p className="text-gray-500 text-[12px] md:text-sm my-[2px]">
                          {appointment?.tutorId.email}
                        </p>
                        <p className="text-gray-500 text-[12px] md:text-sm">
                          {appointment.appointmentDate}
                        </p>
                      </div>
                      <div className="badge badge-success mt-1 lg:mt-0">
                        {appointment.status}
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-4 items-start my-5 lg:mt-5 lg:mr-5">
                    <button
                      onClick={() => deleteAppointment(appointment._id)}
                      className="btn btn-error"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p>No previous appointments.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Appointments;
