/* eslint-disable react/prop-types */
import Header from "./Header";
import Footer from "./Footer";
import { useEffect } from "react";

const Layout = ({ children }) => {
  return (
    <>
      <Header />
      <main className="container mx-auto">{children}</main>
      <Footer />
    </>
  );
};

export default Layout;
