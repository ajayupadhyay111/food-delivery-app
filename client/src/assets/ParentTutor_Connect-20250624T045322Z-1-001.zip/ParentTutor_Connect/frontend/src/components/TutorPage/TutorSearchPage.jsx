import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { axiosInstance } from "../../utils/axios";
import toast from "react-hot-toast";
import { set } from "mongoose";

const TutorSearchPage = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredTutors, setFilteredTutors] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  // Handle search input change
  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  useEffect(() => {
    (async () => {
      try {
        setIsLoading(true);
        const response = await axiosInstance.get(
          `/interaction/search/tutors?searchTerm=${searchTerm}`
        );
        console.log(response);
        if (response.status === 200) {
          setFilteredTutors(response.data.data);
        } else {
          console.log("Error fetching tutors:", response.status);
        }
      } catch (error) {
        console.log(error.message);
        toast.error(error?.response?.message || error.message);
      } finally {
        setIsLoading(false);
      }
    })();
    window.scrollTo(0, 0); // Scroll page to top on route change
  }, [searchQuery]);

  const handleQuery = () => {
    setSearchQuery(searchTerm);
  };

  return (
    <div className="p-6 mt-20">
      <h1 className="text-2xl font-semibold mb-4">Search Tutors</h1>
      <div className="flex justify-center">
        <div className="border-[1px] w-80  flex rounded-sm md:w-fit">
          <input
            type="text"
            value={searchTerm}
            onChange={handleSearchChange}
            placeholder="Search by name or subject "
            className="p-2 py-4 rounded-r-none border-0 w-[80%] rounded md:w-86 outline-none"
          />
          <button
            onClick={handleQuery}
            className="btn p-2 px-4 btn-primary rounded-l-none rounded-r-sm border text-base h-full shadow-none"
          >
            Search
          </button>
        </div>
      </div>

      <div className="flex gap-10 justify-center flex-wrap mt-14">
        {isLoading && <p>loading...</p>}
        {filteredTutors?.length === 0 ? (
          <p>No tutors found</p>
        ) : (
          filteredTutors?.map((tutor, index) => (
            <div
              key={index}
              className="relative bg-gray-800 shadow-lg rounded-lg p-6 w-full sm:w-80 h-88"
            >
              <div className="flex items-center mb-4">
                <img
                  src={tutor.profilePicture || "default_profile_picture.jpg"}
                  alt={tutor.fullName}
                  className="w-20 h-20 rounded-full object-cover"
                />
                <div className="ml-4">
                  <h2 className="text-xl font-semibold">{tutor.fullName}</h2>
                  <p className="text-gray-400 text-sm">{tutor.role}</p>
                </div>
              </div>

              <div className="mb-2">
                <h3 className="text-lg font-semibold">Subjects:</h3>
                <ul className="list-disc pl-6 text-gray-400">
                  {tutor.subjects.map((subject, index) => (
                    <li key={index}>{subject}</li>
                  ))}
                </ul>
              </div>

              <div className="mb-2">
                <h3 className="text-lg font-semibold">Experience:</h3>
                <p className="text-gray-400">
                  {tutor.experience} years of experience
                </p>
              </div>
              <div className="flex justify-end mt-3 absolute bottom-5 right-5 ">
                <Link to={`/tutor/detail-page/${tutor._id}`}>
                  <button className="btn ">View Details</button>
                </Link>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default TutorSearchPage;
