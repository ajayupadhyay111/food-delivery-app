import React, { useEffect, useState } from "react";
import { axiosInstance } from "../../../utils/axios";
import toast from "react-hot-toast";

const TutorAppointments = () => {
  const [appointments, setAppointments] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const response = await axiosInstance.get(
          "/appointment/appointmentsbyTutor"
        );
        if (response?.status === 200) {
          setAppointments(response.data.appointments);
        }
      } catch (error) {}
    })();
  }, []);

  const handleAppointmentStatus = async (status, id) => {
    try {
      setIsLoading(true);
      const response = await axiosInstance.patch(`/appointment/${id}/status`, {
        status,
      });
      if (response.status === 200) {
        toast.success(response.data.message);
        setAppointments(
          appointments.map((appointment) =>
            appointment._id === id ? { ...appointment, status } : appointment
          )
        );
      }
    } catch (error) {
      console.log(error);
      toast.error(response?.error?.message || error.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className=" min-h-screen w-full bg-gray-800 p-6">
      <div className=" rounded-lg md:p-6 w-full">
        <div className="w-full">
          <h3 className="text-xl font-semibold mb-4">Previous Appointments</h3>
          {appointments.length > 0 ? (
            <div className="space-y-3 flex gap-3 flex-wrap w-full">
              {appointments.map((appointment) => (
                <div
                  className="w-full border-2 lg:flex px-4 pt-3 lg:p-4 lg:px-0 lg:items-start lg:justify-between rounded-md "
                  key={appointment._id}
                >
                  <div className="flex items-center">
                    <div className="lg:pl-5 flex md:flex-col gap-4 justify-between w-full">
                      <div>
                        <h1 className="text-gray-300 font-bold text-xl">
                          {appointment.parentId.fullName}
                        </h1>
                        <p className="text-gray-500 text-sm my-[2px]">
                          {appointment.parentId.email}
                        </p>
                        <p className="text-gray-500 text-sm">
                          {appointment.appointmentDate}
                        </p>
                      </div>
                      <div className="badge badge-success mt-1 lg:mt-0">
                        {appointment.status}
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-4 items-start my-5 lgmt-5 lg:mr-5">
                    <button
                      onClick={() =>
                        handleAppointmentStatus("confirmed", appointment._id)
                      }
                      className="btn btn-primary"
                    >
                      Accept
                    </button>
                    <button
                      onClick={() =>
                        handleAppointmentStatus("canceled", appointment._id)
                      }
                      className="btn btn-accent"
                    >
                      Reject
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p>No previous appointments.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default TutorAppointments;
