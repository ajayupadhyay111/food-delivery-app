import { configureStore } from "@reduxjs/toolkit";
import userReducer from "./features/userSlice"; // adjust the path based on where your userSlice file is located

const store = configureStore({
  reducer: {
    user: userReducer, // Register the userSlice reducer here
  },
});

export default store;
