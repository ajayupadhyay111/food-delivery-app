import { createSlice } from "@reduxjs/toolkit";
const user =
  localStorage.getItem("user") === "undefined"
    ? null
    : JSON.parse(localStorage.getItem("user")); // LocalStorage se data le lo
const initialState = {
  user: user || null, // LocalStorage se data le lo
  isAuthenticated: localStorage.getItem("user") ? true : false, // Agar user hai toh authenticated true
};
const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    setUser: (state, action) => {
      state.user = action.payload;
      state.isAuthenticated = true;
      localStorage.setItem("user", JSON.stringify(action.payload));
    },
    logout: (state) => {
      state.user = null;
      state.isAuthenticated = false;
      localStorage.removeItem("user");
    },
  },
});

export const { setUser, logout } = userSlice.actions;
export default userSlice.reducer;
