# Parent-Tutor Platform

## Key Features

### For Parents:

- **Search and Filter**: Locate tutors based on subjects, location, experience, ratings, and more.
- **Profile View**: Access detailed profiles of tutors, including their qualifications, teaching methods, and availability.
- **Direct Communication**: Use a built-in chat or messaging system to connect with tutors.
- **Booking System**: Schedule and manage sessions with selected tutors.
- **Rating and Review**: Share feedback to help other parents make informed decisions.

### For Tutors:

- **Profile Creation**: Create detailed profiles highlighting qualifications, expertise, and teaching preferences.
- **Dashboard**: Manage schedules, inquiries, and bookings efficiently.
- **Direct Communication**: Interact with parents through the platform's chat system.
- **Ratings Display**: Showcase reviews from parents to build credibility.

# Tutor-Parent Platform API Routes

This document outlines the API routes for connecting tutors and parents on the platform. The routes are divided into different categories based on functionality.

## Authentication Routes

- **POST `/api/auth/signup`**  
  Registers a new user (either a tutor or a parent).
- **POST `/api/auth/login`**  
  Logs a user in (either a tutor or a parent).
- **POST `/api/auth/logout`**  
  Logs a user out.

- **POST `/api/auth/forgot-password`**  
  Sends a password reset request.

## Profile Routes

- **GET `/api/user/profile`**  
  Fetches the profile information of the logged-in user.
- **PUT `/api/user/profile`**  
  Updates the profile of the logged-in user.

- **GET `/api/user/tutor-details`**  
  Fetches detailed information about a specific tutor (for parents).

- **GET `/api/user/parent-details`**  
  Fetches detailed information about a specific parent (for tutors).

## Tutors & Parents Interaction Routes

- **GET `/api/tutors`**  
  Lists available tutors, with filtering options by subject, location, rating, etc.

- **GET `/api/tutors/:id`**  
  Fetches details of a specific tutor by their ID.

- **POST `/api/appointments`**  
  Allows a parent to schedule an appointment with a tutor.

- **GET `/api/appointments/:id`**  
  Fetches details of a specific appointment by its ID.

- **PUT `/api/appointments/:id`**  
  Allows a parent or tutor to update an existing appointment.

  <!-- yaha tak ke saare routes ban chuke hain 👍-->

## Reviews & Ratings Routes

- **POST `/api/reviews`**  
  Allows a parent to leave a review and rating for a tutor after a session.

- **GET `/api/reviews/:tutorId`**  
  Fetches the reviews and ratings of a specific tutor.

## Messaging or Communication Routes

- **POST `/api/messages`**  
  Allows tutors and parents to send messages to each other.

- **GET `/api/messages/:conversationId`**  
  Fetches the message history of a specific conversation.

## Payment & Subscription Routes

- **POST `/api/payment`**  
  Processes payments for tutoring sessions.

- **GET `/api/subscriptions`**  
  Lists available subscription plans (if applicable).

## Admin Routes (Optional)

- **GET `/api/admin/users`**  
  Fetches a list of all users (both tutors and parents).

- **DELETE `/api/admin/users/:id`**  
  Deletes a specific user by their ID (admin only).

---

### Notes:

- Routes requiring user authentication should include a valid JWT token in the `Authorization` header.
- The payment and subscription routes may need to be integrated with a payment gateway (e.g., Stripe, PayPal).
