1. Add rate limiting on login requests to prevent brute force attacks.
2. Captures the parent's rating and feedback for the tutor after the session is completed.
3. Jo Jo appointment current date se pahle ki hain unke status ko update nhi kar sakte
4. Appointment book karte wakt zoom link bhi le sakte ho
5. Admin tutor se kuch subscription le sakta hai aur usko verified kar sakta hai `verified` field already hai model mein.
6. Zegocloud use kar sakte ho for video calling
