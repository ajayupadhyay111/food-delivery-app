// socket.js
import { Server } from "socket.io";
import Message from "./models/message.model.js";
// Store connected users
let onlineUsers = new Map();
export const setupSocket = (server) => {
  const io = new Server(server, {
    cors: {
      origin: "http://localhost:5173",
      credentials: true, // Allow sending cookies in requests
    },
  });

  io.on("connection", (socket) => {
    console.log("🔵 A user connected:", socket.id);

    // ✅ User join event
    socket.on("join", ({ userId, userType }) => {
      console.log(`🟢 ${userType} (${userId}) joined`);
      onlineUsers.set(userId, socket.id);
    });

    // ✅ Message sending logic
    socket.on(
      "sendMessage",
      async ({ senderId, receiverId, content, userType }) => {
        console.log(
          `📩 Message from ${senderId} to ${receiverId}: ${content} and ${userType}`
        );

        // Save message in database

        const newMessage = new Message({
          senderType: userType,
          sender: senderId,
          receiver: receiverId,
          content,
        });
        await newMessage.save();

        // Agar receiver online hai toh usko message bhejo
        const receiverSocketId = onlineUsers.get(receiverId);
        if (receiverSocketId) {
          io.to(receiverSocketId).emit("receiveMessage", newMessage);
        }
      }
    );

    // ✅ User disconnect event
    socket.on("disconnect", () => {
      console.log("🔴 A user disconnected:", socket.id);
      onlineUsers.forEach((socketId, userId) => {
        if (socketId === socket.id) {
          onlineUsers.delete(userId);
        }
      });
    });
  });

  return io;
};
