export const newMessage = async (req, res, next) => {
  console.log("hello");
};

export const getAllMessages = async (req, res, next) => {
  console.log("hello");
};
