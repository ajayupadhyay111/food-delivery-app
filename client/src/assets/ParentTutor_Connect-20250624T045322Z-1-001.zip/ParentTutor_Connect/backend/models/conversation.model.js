import mongoose from "mongoose";
const conversationSchema = new mongoose.Schema(
  {
    tutor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Tutor",
      required: true,
    }, // Tutor ID
    parent: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Parent",
      required: true,
    }, // Parent ID
    latestMessage: { type: mongoose.Schema.Types.ObjectId, ref: "Message" }, // Last message
  },
  { timestamps: true }
);

const Conversation = mongoose.model("Conversation", conversationSchema);
export default Conversation;
