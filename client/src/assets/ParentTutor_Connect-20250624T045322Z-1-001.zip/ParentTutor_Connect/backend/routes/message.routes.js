import express from "express";
import isAuthenticated from "../middlewares/protectRoute.js";
import {
  getAllMessages,
  newMessage,
} from "../controllers/message.controller.js";

const messageRoutes = express.Router();

// Define a simple route
messageRoutes.post("/newMessage", isAuthenticated, newMessage);
messageRoutes.get("/", isAuthenticated, getAllMessages);
// messageRoutes.put("/message/:id", isAuthenticated, updateMessage);
// messageRoutes.delete("/message/:id", isAuthenticated, deleteMessage);

export default messageRoutes;
