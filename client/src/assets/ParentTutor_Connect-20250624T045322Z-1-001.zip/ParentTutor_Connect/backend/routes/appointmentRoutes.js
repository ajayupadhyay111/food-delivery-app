import express from "express";
import {
  createAppointment,
  deleteAppointment,
  getAppointmentsByParent,
  getAppointmentsByTutor,
  updateAppointmentStatus,
} from "../controllers/appointment.controller.js";
import isAuthenticated from "../middlewares/protectRoute.js";
const router = express.Router();

router.post("/create/:tutorId", isAuthenticated, createAppointment);
router.get("/appointmentsbyTutor", isAuthenticated, getAppointmentsByTutor);
router.get("/appointmentsbyParent", isAuthenticated, getAppointmentsByParent);
router.patch(
  "/:appointmentId/status",
  isAuthenticated,
  updateAppointmentStatus
);
router.delete("/:appointmentId", isAuthenticated, deleteAppointment);

export default router;
